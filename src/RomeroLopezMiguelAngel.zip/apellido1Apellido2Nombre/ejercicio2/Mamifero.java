package apellido1Apellido2Nombre.ejercicio2;

class Mamifero extends Animal {
    private int tiempoDeGestacion;

    public Mamifero(String nombre, double peso, double altura, String deCompania, int tiempoDeGestacion) {
        super(nombre, peso, altura, deCompania);
        this.tiempoDeGestacion = tiempoDeGestacion >= 0 ? tiempoDeGestacion : 0;
    }

    public int getTiempoDeGestacion() {
        return tiempoDeGestacion;
    }

    public void setTiempoDeGestacion(int tiempoDeGestacion) {
        this.tiempoDeGestacion = tiempoDeGestacion >= 0 ? tiempoDeGestacion : 0;
    }

    @Override
    int fecundacion() {
        return tiempoDeGestacion;
    }

    @Override
    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Tiempo de gestación: " + tiempoDeGestacion + " días");
    }
}

class Ave extends Animal {
    private int tiempoDeIncubacion;
    private boolean tienePlumas;

    public Ave(String nombre, double peso, double altura, String deCompania, int tiempoDeIncubacion, boolean tienePlumas) {
        super(nombre, peso, altura, deCompania);
        this.tiempoDeIncubacion = tiempoDeIncubacion >= 0 ? tiempoDeIncubacion : 0;
        this.tienePlumas = tienePlumas;
    }

    public int getTiempoDeIncubacion() {
        return tiempoDeIncubacion;
    }

    public void setTiempoDeIncubacion(int tiempoDeIncubacion) {
        this.tiempoDeIncubacion = tiempoDeIncubacion >= 0 ? tiempoDeIncubacion : 0;
    }

    public boolean isTienePlumas() {
        return tienePlumas;
    }

    public void setTienePlumas(boolean tienePlumas) {
        this.tienePlumas = tienePlumas;
    }

    @Override
    int fecundacion() {
        return tiempoDeIncubacion;
    }

    @Override
    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Tiempo de incubación: " + tiempoDeIncubacion + " días");
        System.out.println("¿Tiene plumas?: " + (tienePlumas ? "Sí" : "No"));
    }
}

