package apellido1Apellido2Nombre.ejercicio2;

public class Main {
    public static void main(String[] args) {
        Mamifero perro = new Mamifero("Perro", 15, 30, "SI", 63);
        Mamifero gato = new Mamifero("Gato", 5, 20, "SI", 30);
        Mamifero vaca = new Mamifero("Vaca", 145, 180, "NO", 426);
        Ave gaviota = new Ave("Gaviota", 4, 40, "SI", 120, true);
        Ave paloma = new Ave("Paloma", 0.5, 10, "SI", 30, true);

        Zoo zoo = new Zoo();
        zoo.mostrarInformacion();

    }
}
