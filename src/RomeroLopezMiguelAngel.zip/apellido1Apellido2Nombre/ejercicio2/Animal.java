package apellido1Apellido2Nombre.ejercicio2;

public abstract class Animal {
    private String nombre;
    private double peso;
    private double altura;
    private DeCompania deCompania;

    public Animal(String nombre, double peso, double altura, String deCompania) {
        this.nombre = nombre;
        this.peso = peso >= 0 ? peso : 0;
        this.altura = altura >= 0 ? altura : 0;
        this.deCompania = DeCompania.valueOf(deCompania.toUpperCase());
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso >= 0 ? peso : 0;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura >= 0 ? altura : 0;
    }

    public DeCompania getDeCompania() {
        return deCompania;
    }

    public void setDeCompania(String deCompania) {
        this.deCompania = DeCompania.valueOf(deCompania.toUpperCase());
    }

    abstract int fecundacion();

    public void mostrarInformacion() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Peso: " + peso + " kg");
        System.out.println("Altura: " + altura + " cm");
        System.out.println("Es de compañia?: " + deCompania);
    }
}

enum DeCompania {
    SI, NO, DEPENDE
}



