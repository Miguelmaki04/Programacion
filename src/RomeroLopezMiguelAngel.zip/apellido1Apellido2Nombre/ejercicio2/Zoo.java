package apellido1Apellido2Nombre.ejercicio2;

import java.util.ArrayList;

public class Zoo {
        private ArrayList<Mamifero> mamiferos;
        private ArrayList<Ave> aves;

        public Zoo() {
            mamiferos = new ArrayList<>();
            aves = new ArrayList<>();
        }

        public int compararNombres(int indice) {
            String nombreMamifero = mamiferos.get(indice).getNombre();
            String nombreAve = aves.get(indice).getNombre();
            int letrasCoincidentes = 0;
            int minLength = Math.min(nombreMamifero.length(), nombreAve.length());
            for (int i = 0; i < minLength; i++) {
                if (nombreMamifero.charAt(i) == nombreAve.charAt(i)) {
                    letrasCoincidentes++;
                }
            }
            return letrasCoincidentes;
        }

        public void mostrarInformacion() {
            System.out.println("Animales del zoo");
            System.out.println("Mamiferos:");
            for (Mamifero mamifero : mamiferos) {
                System.out.println("Nombre: " + mamifero.getNombre());
                System.out.println("Peso: " + mamifero.getPeso() + " kg");
                System.out.println("Altura: " + mamifero.getAltura() + " cm");
                System.out.println("Tiempo de gestacion: " + mamifero.getTiempoDeGestacion());
            }
            System.out.println("Aves:");
            for (Ave ave : aves) {
                System.out.println("Nombre: " + ave.getNombre());
                System.out.println("Peso: " + ave.getPeso() + " kg");
                System.out.println("Altura: " + ave.getAltura() + " cm");
                System.out.println("Tiempo de incubacion: " + ave.getTiempoDeIncubacion());
                System.out.println("Tiene plumas?: " + (ave.isTienePlumas() ? "Si" : "No"));
            }
        }

        public void mostrarNombresOrdenados() {
            int total = Math.max(mamiferos.size(), aves.size());
            for (int i = 0; i < total; i++) {
                if (i < mamiferos.size()) {
                    System.out.println(mamiferos.get(i).getNombre());
                }
                if (i < aves.size()) {
                    System.out.println(aves.get(aves.size() - i - 1).getNombre());
                }
            }
        }
}
