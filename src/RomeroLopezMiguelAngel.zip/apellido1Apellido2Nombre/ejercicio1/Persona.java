package apellido1Apellido2Nombre.ejercicio1;
public class Persona implements Hablar {
    private String nombre;
    private int edad;
    private String direccion;

    public Persona(String nombre, int edad, String direccion) {
        this.nombre = nombre;
        setEdad(edad);
        this.direccion = direccion;
    }

    public Persona(String nombre, int edad) {
        this(nombre, edad, "Vacio");
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        if (edad >= 0 && edad <= 99) {
            this.edad = edad;
        }
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    @Override
    public String toString() {
        return nombre + ";" + edad + ";" + direccion;
    }

    public void mostrarInfo() {
        System.out.println("Nombre: " + getNombre());
        System.out.println("Edad: " + getEdad());
        System.out.println("Dirección: " + getDireccion());
    }

    @Override
    public void hablar(String mensaje) {
        System.out.println(mensaje + ", mi nombre es " + nombre + " y tengo " + edad + " años.");
    }
}

