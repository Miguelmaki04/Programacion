package apellido1Apellido2Nombre.ejercicio1;
import java.util.Arrays;
class Clase {
    private Estudiante[] estudiantes;
    private final int maxEstudiantes = 25;
    private int contadorEstudiantes;

    public Clase() {
        estudiantes = new Estudiante[maxEstudiantes];
        contadorEstudiantes = 0;
    }

    public void insertarEstudiante(Estudiante estudiante) {
        if (contadorEstudiantes < maxEstudiantes) {
            estudiantes[contadorEstudiantes] = estudiante;
            contadorEstudiantes++;
        } else {
            System.out.println("No puede haber mas estudiantes.");
        }
    }

    public void borrarEstudiante(int posicion) {
        try {
            if (posicion >= 0 && posicion < contadorEstudiantes) {
                for (int i = posicion; i < contadorEstudiantes - 1; i++) {
                    estudiantes[i] = estudiantes[i + 1];
                }
                contadorEstudiantes--;
                estudiantes[contadorEstudiantes] = null;
            } else {
                throw new IndexOutOfBoundsException("Posición fuera de rango");
            }
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void mostrarInfo() {
        for (int i = 0; i < contadorEstudiantes; i++) {
            System.out.println("Estudiante " + (i + 1) + ":");
            estudiantes[i].mostrarInfo();
            System.out.println();
        }
    }
}
