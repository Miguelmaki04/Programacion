package apellido1Apellido2Nombre.ejercicio1;

class Estudiante extends Persona {
    private boolean becado;
    public int notaMedia;

    public Estudiante(String nombre, int edad, String direccion, boolean becado, int notaMedia) {
        super(nombre, edad, direccion);
        this.becado = becado;
        this.notaMedia = notaMedia;
    }

    public boolean isBecado() {
        return becado;
    }

    public void setBecado(boolean becado) {
        this.becado = becado;
    }

    public void setEdad(int notaMedia) {
        if (notaMedia >= 0 && notaMedia <= 10) {
            this.notaMedia = notaMedia;
        }
    }
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Becado: " + becado);
        System.out.println("Nota media: " + notaMedia);
    }
}




