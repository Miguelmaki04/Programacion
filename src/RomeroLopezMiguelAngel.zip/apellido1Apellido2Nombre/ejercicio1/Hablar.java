package apellido1Apellido2Nombre.ejercicio1;

public interface Hablar {
    void hablar(String mensaje);
}
