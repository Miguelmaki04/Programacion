package apellido1Apellido2Nombre.ejercicio1;

public class Main {
    public static void main(String[] args) {
        System.out.println("Persona:");
        Persona persona1 = new Persona("Juan", 25, "Gran Capitan");
        persona1.mostrarInfo();
        System.out.println(persona1);

        System.out.println("\nEstudiante:");
        Estudiante estudiante1 = new Estudiante("Ana", 20, "El Brillante", true, 8);
        estudiante1.mostrarInfo();

        System.out.println("\nClase:");
        Clase clase = new Clase();
        clase.insertarEstudiante(estudiante1);
        clase.mostrarInfo();

        System.out.println("\nHablar:");
        persona1.hablar("Hola");
    }
}
